/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;

import java.sql.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import map.OurMap;
import player.Movement;
import utilities.communications.Comms;
import utilities.graphics.Coordinate;

/**
 *
 * @author Daniel
 */
public class DataBase {

    private final String dbName = "callofpokemondb";
    private Connection con;

    public DataBase() {
        try {
            con = null;
        } catch (Exception ex) {ex.printStackTrace();}
    }

    /**
     * acess the database, needs to be called first to use any method
     *
     * @return the connection with it
     * @throws Exception
     */
    public Connection getConnection() throws Exception {
        Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
        con = DriverManager.getConnection("jdbc:odbc:" + dbName);
        System.out.println("Connected to database.");
        return con;
    }
    
    public void close() throws Exception{
        if(con==null) System.out.println("Not connected to database.");
        else {
            con.close();
            System.out.println("Disconnected from database.");
        }
    }

    public static void main(String[] args) throws Exception {
        DataBase d = new DataBase();
        d.getConnection();
        /*String s[] = d.getScoreBoard(3);
        for(int i=0;i<3;i++)
        System.out.println(s[i]);
        OurMap m = new OurMap();
        m.setType(Comms.field);
        int k = d.addNewMap(m);
        System.out.println(k);
        int kg=d.addNewGame("Normal", k);
        System.out.println(k);
        k=d.addNewPlayer("Sevi", "Zero", 1);
        System.out.println(k);
        k=d.addNewScore(2000, k);
        System.out.println(k);
        int k=d.addNewMovement(1, 100, "LargeAttack", new Coordinate(3,3,2,null), new Coordinate(4,4,1,null), 1);
        System.out.println(k);
        System.out.println(d.getPlayerScore(9));*/
        
    }

    /**
     * gets the top "x" scores data
     *
     * @param x
     * @return string vector with the top 3 scores from top to bottom
     * @throws Exception
     */
    public String[] getScoreBoard(int x) throws Exception {
        String s[] = new String[x];
        Statement stmt = null;
        //because java
        String query = "select PlayerName, Character, GameDate, Score "
                + "from " + dbName + ".ScoreData, "+ dbName + ".Game, "+ dbName + ".Player "
                + "where Player.IdScore = ScoreData.IdScore and Game.IdGame = Player.IdGame "
                + "order by Score desc";
        try {
            stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            System.out.println("Ready to get the ScoreBoard.");
            for (int i = 1; i <= x; i++) {
                rs.next();
                String name = rs.getString("PlayerName");
                String character = rs.getString("Character");
                Date date = rs.getDate("GameDate");
                int punt = rs.getInt("Score");
                s[i-1] = i + ". " + name + ", " + character +  ", " + date +  ", "+ punt;
            }
            rs.close();
        } finally {
            if (stmt != null) {
                stmt.close();
                System.out.println("Ended operations.");
            } else if (con == null) {
                System.out.println("Not connected to database.");
            } else {
                s = new String[x];
                s[0] = "There aren't any scores yet";
            }
        }
        return s;
    }

    /**
     * creates new map in database
     *
     * @param m
     * @return the identificator of the new map created
     * @throws java.lang.Exception
     */
    public int addNewMap(OurMap m) throws Exception {
        Statement stmt = null;
        int key = 0;
        //because java again
        try {
            stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs = stmt.executeQuery("SELECT * FROM " + dbName + ".Map");
            rs.first();
            rs.moveToInsertRow();
            System.out.println("Ready to create the map.");
            rs.updateInt("MapType", m.getType());
            rs.updateInt("Rows", Comms.obstacleRows);
            rs.updateInt("Columns", Comms.obstacleColumns);
            rs.insertRow();
            rs.last();
            key = rs.getInt("IdMap");
            rs.close();
        } finally {
            if (stmt != null) {
                stmt.close();
                System.out.println("Ended operations.");
            }
            else if(con==null) System.out.println("Not connected to database.");
        }
        return key;
    }

    /**
     * adds anew coordinate to the map with the given identification
     *
     * @param c
     * @param mapId
     * @return identificator of the new coordinate
     * @throws java.lang.Exception
     */
    public int addNewCoordinate(Coordinate c, int mapId) throws Exception {
        Statement stmt = null;
        int key = 0;
        try {
            stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs = stmt.executeQuery("SELECT * FROM " + dbName + ".Coordinate");
            rs.first();
            rs.moveToInsertRow();
            System.out.println("Ready to add a coordinate.");
            rs.updateInt("x", c.getX());
            rs.updateInt("y", c.getY());
            rs.updateInt("Obstacle", c.getObstacle());
            rs.updateInt("IdMap", mapId);
            rs.insertRow();
            rs.last();
            key = rs.getInt("IdCoordinate");
            rs.close();
        } finally {
            if (stmt != null) {
                stmt.close();
                System.out.println("Ended operations.");
            }
            else if(con==null) System.out.println("Not connected to database.");
        }
        return key;
    }
    
    /**
     * creates new game to the database with the given parameters
     * @param type of game
     * @param mapId
     * @return identificator of the new map
     * @throws Exception 
     */
    public int addNewGame(String type, int mapId) throws Exception {
        Statement stmt = null;
        int key = 0;
        try {
            stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs = stmt.executeQuery("SELECT * FROM " + dbName + ".Game");
            rs.first();
            rs.moveToInsertRow();
            //gets the current date in a tractable format
            DateFormat year = new SimpleDateFormat("yyyy");
            DateFormat month = new SimpleDateFormat("MM");
            DateFormat day = new SimpleDateFormat("dd");
            Calendar cal = Calendar.getInstance();
            int y = Integer.parseInt(year.format(cal.getTime()))-1900;
            int m = Integer.parseInt(month.format(cal.getTime()))-1;
            int d = Integer.parseInt(day.format(cal.getTime()));
            //new values of new Game
            System.out.println("Ready to create a game.");
            rs.updateDate("GameDate",new Date(y,m,d));
            rs.updateString("TypeOfGame", type);
            rs.updateInt("IdMap", mapId);
            rs.insertRow();
            rs.last();
            key = rs.getInt("IdGame");
            rs.close();
        } finally {
            if (stmt != null) {
                stmt.close();
                System.out.println("Ended operations.");
            }
            else if(con==null) System.out.println("Not connected to database.");
        }
        return key;
    }
    
    /**
     * creates a new player in the database (without scoredata)
     * @param name
     * @param character
     * @param gameId
     * @return identificator of the new player
     * @throws Exception 
     */
    public int addNewPlayer(String name, String character, int gameId) throws Exception {
        Statement stmt = null;
        int key = 0;
        try {
            stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs = stmt.executeQuery("SELECT * FROM " + dbName + ".Player");
            rs.first();
            rs.moveToInsertRow();
            System.out.println("Ready to add a player.");
            rs.updateString("PlayerName",name);
            rs.updateString("Character", character);
            rs.updateInt("IdGame", gameId);
            rs.insertRow();
            rs.last();
            key = rs.getInt("IdPlayer");
            rs.close();
        } finally {
            if (stmt != null) {
                stmt.close();
                System.out.println("Ended operations.");
            }
            else if(con==null) System.out.println("Not connected to database.");
        }
        return key;
    }
    
    /**
     * creates the new score in the database of a specific player
     * @param scoreTime
     * @param playerId
     * @return identificator of the new Score
     * @throws Exception 
     */
    public int addNewScore(long scoreTime, int playerId) throws Exception {
        Statement stmt = null;
        int key = 0;
        try {
            stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs = stmt.executeQuery("SELECT * FROM " + dbName + ".ScoreData");
            rs.first();
            rs.moveToInsertRow();
            System.out.println("Ready to create a score and assign it.");
            rs.updateInt("ScoreTime",(int) scoreTime);
            rs.updateInt("Score", calculateScore(scoreTime));
            rs.insertRow();
            rs.last();
            key = rs.getInt("IdScore");
            rs.close();
            //assign the score to the player
            stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            rs = stmt.executeQuery("SELECT * FROM " + dbName + ".Player WHERE Player.IdPlayer = "+playerId);
            rs.first();
            rs.updateInt("IdScore", key);
            rs.updateRow();
            rs.close();
        } finally {
            if (stmt != null) {
                stmt.close();
                System.out.println("Ended operations.");
            }
            else if(con==null) System.out.println("Not connected to database.");
        }
        return key;
    }

    /**
     * algorith to calculate the score
     * @param scoreTime
     * @return score (points)
     */
    private int calculateScore(long scoreTime) {
        return 10000-((int) scoreTime);
    }
    
    /**
     * adds a new movement to the database of a selected game
     * @param direction
     * @param timeInstant
     * @param type
     * @param cini
     * @param cfin
     * @param gameId
     * @return identificator of the Movement
     * @throws Exception 
     */
    public int addNewMovement(int direction, long timeInstant, String type, Coordinate cini, Coordinate cfin, int gameId) throws Exception {
        Statement stmt = null;
        int key = 0;
        try {
            stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            System.out.println("Ready to record a new movement.");
            ResultSet rs = stmt.executeQuery("SELECT * FROM " + dbName + ".Game "
                    + "WHERE Game.IdGame = "+gameId);
            rs.next();
            key=rs.getInt("IdMap");
            rs.close();
            rs = stmt.executeQuery("SELECT * FROM " + dbName + ".Movement");
            rs.first();
            rs.moveToInsertRow();
            rs.updateInt("Direction",direction);
            rs.updateInt("TimeInstant", (int) timeInstant);
            rs.updateString("Type", type);
            rs.updateInt("IdGame", gameId);
            rs.updateInt("IdCoordinateIni", getIdCoordinate(cini,key));
            rs.updateInt("IdCoordinateFin", getIdCoordinate(cfin,key));
            rs.insertRow();
            rs.last();
            key = rs.getInt("IdMovement");
            rs.close();
        } finally {
            if (stmt != null) {
                stmt.close();
                System.out.println("Ended operations.");
            }
            else if(con==null) System.out.println("Not connected to database.");
        }
        return key;
    }
    
    /**
     * gets the id of a given coordinate in a given idMap
     * (if the map has been created the coordinate must exist and it must be unique)
     * @param c
     * @param idMap
     * @return id of the coordinate
     * @throws Exception 
     */
    public int getIdCoordinate(Coordinate c, int idMap) throws Exception{
        Statement stmt = null;
        int key = 0;
        try {
            stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs = stmt.executeQuery("SELECT * FROM " + dbName + ".Coordinate "
                    + "WHERE Coordinate.x = "+c.getX()+" AND "
                    + "Coordinate.y = "+c.getY()+ " AND "
                    + "Coordinate.IdMap = "+idMap);
            rs.next();
            key = rs.getInt("IdCoordinate");
            rs.close();
        } finally {
            if (stmt != null) {
                stmt.close();
            }
            else if(con==null) System.out.println("Not connected to database.");
        }
        return key;
    }
    
    /**
     * deleted a recorded game specified by and idGame
     * @param gameId
     * @throws Exception 
     */
    public void removeRecord(int gameId) throws Exception {
        Statement stmt = null;
        try {
            stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            System.out.println("Ready to delete the record.");
            ResultSet rs = stmt.executeQuery("SELECT * FROM " + dbName + ".Movement "
                    + "WHERE Movement.IdGame = "+gameId);
            while(rs.next()){
                rs.deleteRow();
            }
            rs.close();
        } finally {
            if (stmt != null) {
                stmt.close();
                System.out.println("Ended operations.");
            }
            else if(con==null) System.out.println("Not connected to database.");
        }
    }
    
    /**
     * gets a specified record of a game
     * @param gameId
     * @return array of movements
     * @throws Exception 
     */
    public ArrayList<Movement> getRecord(int gameId) throws Exception {
        Statement stmt = null;
        ArrayList<Movement> mov = new ArrayList<>();
        try {
            stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            System.out.println("Ready to get the record.");
            ResultSet rs = stmt.executeQuery("SELECT * FROM " + dbName + ".Movement "
                    + "WHERE Movement.IdGame = " + gameId);
            while(rs.next()){
                int d=rs.getInt("Direction");
                long t = rs.getInt("TimeInstant");
                String type = rs.getString("Type");
                Coordinate cini = getCoordinate(rs.getInt("IdCoordinateIni"));
                Coordinate cfin = getCoordinate(rs.getInt("IdCoordinateFin"));
                mov.add(new Movement(type,d,cini,cfin,t));
            }
            rs.close();
        } finally {
            if (stmt != null) {
                stmt.close();
                System.out.println("Ended operations.");
            }
            else if(con==null) System.out.println("Not connected to database.");
            else System.out.println("This record doesn't exist.");
        }
        return mov;
    }

    /**
     * gets the given coordinate on the database of coordinates
     * @param idCoord
     * @return coordinate found
     * @throws Exception 
     */
    private Coordinate getCoordinate(int idCoord) throws Exception {
        Statement stmt = null;
        Coordinate c = null;
        try {
            stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs = stmt.executeQuery("SELECT * FROM " + dbName + ".Coordinate "
                    + "WHERE Coordinate.IdCoordinate = " + idCoord);
            rs.next();
            int x = rs.getInt("x");
            int y = rs.getInt("y");
            int o = rs.getInt("Obstacle");
            c = new Coordinate(x,y,o,null);
            rs.close();
        } finally {
            if (stmt != null) {
                stmt.close();
            }
            else if(con==null) System.out.println("Not connected to database.");
        }
        return c;
    }
    
    /**
     * gets the score of a player
     * @param idPlayer
     * @return string with the score information
     * @throws Exception 
     */
    public String getPlayerScore(int idPlayer) throws Exception {
        Statement stmt = null;
        String s = "Couldn't find the score...";
        try {
            stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs = stmt.executeQuery("SELECT PlayerName, Character, GameDate, Score FROM "
                    + dbName + ".Player, "+dbName + ".ScoreData, "+dbName + ".Game "
                    + "WHERE Player.IdGame = Game.IdGame and Player.IdScore = ScoreData.IdScore "
                    + "and Player.IdPlayer = "+idPlayer);
            System.out.println("Ready to get the Score of the player.");
            rs.next();
            String name = rs.getString("PlayerName");
            String character = rs.getString("Character");
            Date date = rs.getDate("GameDate");
            int punt = rs.getInt("Score");
            s = name + ", " + character + ", " + date + ", " + punt;
            rs.close();
        } finally {
            if (stmt != null) {
                stmt.close();
                System.out.println("Ended operations.");
            }
            else if(con==null) System.out.println("Not connected to database.");
        }
        return s;
    }
}
